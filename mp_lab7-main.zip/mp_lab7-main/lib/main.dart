import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/create_post_screen.dart';
import 'screens/currency_screen.dart';

/// Main entry point of the Flutter app
/// Demonstrates API requests, navigation, and UI updates
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MP Lab 7 - API Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 2,
        ),
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      // Initial route
      initialRoute: '/',
      // Named routes for navigation
      routes: {
        '/': (context) => const HomeScreen(),
        '/create': (context) => const CreatePostScreen(),
        '/currency': (context) => const CurrencyScreen(),
      },
    );
  }
}
