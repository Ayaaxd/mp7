import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/currency.dart';

/// Part E: CurrencyScreen - Fetch and display currency rates from CBU.uz API
class CurrencyScreen extends StatefulWidget {
  const CurrencyScreen({super.key});

  @override
  State<CurrencyScreen> createState() => _CurrencyScreenState();
}

class _CurrencyScreenState extends State<CurrencyScreen> {
  final _dateController = TextEditingController();
  final _currencyCodeController = TextEditingController();
  
  List<Currency> _currencies = [];
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _dateController.dispose();
    _currencyCodeController.dispose();
    super.dispose();
  }

  /// 15. Build API URL based on user input
  String _buildApiUrl() {
    final date = _dateController.text.trim();
    final code = _currencyCodeController.text.trim().toUpperCase();

    // Base URL
    String url = 'https://cbu.uz/ru/arkhiv-kursov-valyut/json/';

    if (date.isEmpty && code.isEmpty) {
      // a. All currencies for today
      return url;
    } else if (date.isNotEmpty && code.isEmpty) {
      // b. All currencies for specific date
      return '${url}all/$date/';
    } else if (date.isNotEmpty && code.isNotEmpty) {
      // c. One currency for specific date
      return '$url$code/$date/';
    } else if (date.isEmpty && code.isNotEmpty) {
      // Today's rate for specific currency (not documented but logical)
      return '$url$code/';
    }

    return url;
  }

  /// 15. Fetch currency rates from CBU.uz API
  Future<void> _fetchCurrencyRates() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _currencies = [];
    });

    try {
      final url = _buildApiUrl();
      print('Fetching from URL: $url');

      final response = await http.get(Uri.parse(url));

      print('Response Status: ${response.statusCode}');
      print('Response Body (first 200 chars): ${response.body.length > 200 ? response.body.substring(0, 200) : response.body}...');

      if (response.statusCode == 200) {
        final dynamic jsonData = json.decode(response.body);
        
        List<Currency> currencies = [];
        
        // Check if response is a list or single object
        if (jsonData is List) {
          currencies = jsonData.map((json) => Currency.fromJson(json)).toList();
        } else if (jsonData is Map) {
          currencies = [Currency.fromJson(jsonData)];
        }

        setState(() {
          _currencies = currencies;
          _isLoading = false;
        });

        if (_currencies.isEmpty) {
          setState(() {
            _errorMessage = 'No currency data found';
          });
        }
      } else {
        throw Exception('Failed to load currency rates (Status: ${response.statusCode})');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Error: $e';
      });
      print('Error fetching currency rates: $e');
    }
  }

  /// Show date picker
  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    
    if (picked != null) {
      setState(() {
        // Format as YYYY-MM-DD
        _dateController.text = 
            '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Currency Rates'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Input Section
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.green[50],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'CBU.uz Exchange Rates',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                
                // 15. TextField for date (YYYY-MM-DD)
                TextField(
                  controller: _dateController,
                  decoration: InputDecoration(
                    labelText: 'Date (YYYY-MM-DD)',
                    hintText: 'Leave empty for today',
                    prefixIcon: const Icon(Icons.calendar_today),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _dateController.clear();
                      },
                    ),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  readOnly: true,
                  onTap: _selectDate,
                ),
                const SizedBox(height: 12),
                
                // 15. TextField for currency code
                TextField(
                  controller: _currencyCodeController,
                  decoration: InputDecoration(
                    labelText: 'Currency Code',
                    hintText: 'e.g., USD, RUB, EUR (or leave empty for all)',
                    prefixIcon: const Icon(Icons.attach_money),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _currencyCodeController.clear();
                      },
                    ),
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  textCapitalization: TextCapitalization.characters,
                ),
                const SizedBox(height: 16),
                
                // 15. "Fetch Rates" button
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _fetchCurrencyRates,
                  icon: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.download),
                  label: Text(_isLoading ? 'Fetching...' : 'Fetch Rates'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                
                // Quick action buttons
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    FilterChip(
                      label: const Text('USD'),
                      onSelected: (selected) {
                        _currencyCodeController.text = 'USD';
                      },
                    ),
                    FilterChip(
                      label: const Text('EUR'),
                      onSelected: (selected) {
                        _currencyCodeController.text = 'EUR';
                      },
                    ),
                    FilterChip(
                      label: const Text('RUB'),
                      onSelected: (selected) {
                        _currencyCodeController.text = 'RUB';
                      },
                    ),
                    FilterChip(
                      label: const Text('All'),
                      onSelected: (selected) {
                        _currencyCodeController.clear();
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          // Results Section
          Expanded(
            child: _buildResultsSection(),
          ),
        ],
      ),
    );
  }

  /// Build results section based on state
  Widget _buildResultsSection() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading currency rates...'),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                color: Colors.red,
                size: 60,
              ),
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      );
    }

    if (_currencies.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.currency_exchange,
              size: 80,
              color: Colors.grey,
            ),
            SizedBox(height: 16),
            Text(
              'No data yet',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Enter date and currency code, then tap "Fetch Rates"',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }

    // 15. Display results in ListView
    return ListView.builder(
      itemCount: _currencies.length,
      padding: const EdgeInsets.all(8),
      itemBuilder: (context, index) {
        final currency = _currencies[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
          elevation: 2,
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.green,
              child: Text(
                currency.code.substring(0, 2),
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            title: Text(
              currency.name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Code: ${currency.code}'),
                Text(
                  'Date: ${currency.date}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.green[100],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${currency.rate}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                  const Text(
                    'UZS',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
