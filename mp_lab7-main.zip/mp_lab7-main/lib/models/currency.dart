/// Model class for Currency from CBU.uz API
class Currency {
  final String code;
  final String name;
  final String rate;
  final String date;

  Currency({
    required this.code,
    required this.name,
    required this.rate,
    required this.date,
  });

  /// Factory constructor to create Currency from JSON
  factory Currency.fromJson(Map<String, dynamic> json) {
    return Currency(
      code: json['Ccy'] as String,
      name: json['CcyNm_EN'] as String,
      rate: json['Rate'] as String,
      date: json['Date'] as String,
    );
  }
}
